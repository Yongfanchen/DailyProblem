#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include <math.h>
#include <algorithm>

#include "d3plotreader.h"
#include "binoutreader.h"

using namespace std;

//-------------description of input parameters--------------//
//--argv[1]: file path of dsplot
//--argv[2]: path of output file floder
//----------------------------------------------------------//

int main(int argc,char** argv)
{
	//======================D3plotReader======================
	string d3plot_file = argv[1];
	string::size_type pos = d3plot_file.find('/');
	while(pos != string::npos)
	{
		d3plot_file.replace(pos, 1, "\\");
		pos = d3plot_file.find('/');
	}
	D3plotReader dr(d3plot_file.c_str());
	D3P_Parameter param;
	cout << "=============== D3plotReader ===============" << endl;

	char title[80];
	dr.GetData(D3P_TITLE, (char*)title);
	cout << "title: " << title << endl;
	
	int num_states = 0;
	dr.GetData(D3P_NUM_STATES, (char*)&num_states);
	cout << "num states: " << num_states << endl;
	
	float* state_times =  new float[num_states];
	dr.GetData(D3P_TIMES, (char*)state_times);

	string output_folder = argv[2];
	string output_file = output_folder + "state_time";
	ofstream fs_output;
	fs_output.open(output_file, ios::out);
	fs_output.precision(8);

	for(int i = 0; i < num_states; i++)
	{
		 fs_output << i+1 << '\t' << state_times[i] << endl;
	}
	
	fs_output.close();

	return 0;
}
