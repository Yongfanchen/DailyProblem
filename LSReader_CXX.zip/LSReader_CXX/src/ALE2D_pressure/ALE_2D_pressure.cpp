#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include <math.h>
#include <algorithm>

#include "d3plotreader.h"
#include "binoutreader.h"

#define PI 3.141592653589793

using namespace std;

double angleNum = 0;
double radiusNum = 0;
double gridRatio = 0;

struct DataRange
{
	double range;
	double min;
	double max;
};

DataRange GetDataRange(vector<double> data)
{
	DataRange dataRange;
	auto maxPos = max_element(data.begin(), data.end());
	auto minPos = min_element(data.begin(), data.end());
	dataRange.range = abs(*maxPos - *minPos);
	dataRange.min = *minPos;
	dataRange.max = *maxPos;
	return dataRange;
}

struct PolarCoordinate
{
	double r;
	double theta;
};

struct CartesianCoordinate
{
	double x;
	double y;
};

PolarCoordinate Cartesian2Polar(CartesianCoordinate carCoord)
{
	PolarCoordinate polCoord;
	polCoord.r = sqrt(pow(carCoord.x,2) + pow(carCoord.y,2));
	if(polCoord.r == 0)
	{
		polCoord.theta = 0;
	}
	else
	{
		polCoord.theta = atan2(carCoord.y,carCoord.x);
	}
	return polCoord;
}

struct Index
{
	int i;
	int j;
};

double GetCoreRadius(vector<double> filedRadius)
{
	DataRange dataRange_radius = GetDataRange(filedRadius);
	double basicRadius = 0.0;
	if(gridRatio == 1)
	{
		basicRadius = dataRange_radius.range / radiusNum;
	}
	else
	{
		basicRadius = dataRange_radius.range * (1 - gridRatio) / (1 - pow(gridRatio, radiusNum));
	}
	return basicRadius;
}

Index GetIndex_CircleField(CartesianCoordinate carCoord, vector<double> fieldRadius, vector<double> fieldAngle)
{
	DataRange dataRange_radius = GetDataRange(fieldRadius);
	double basicRadius = GetCoreRadius(fieldRadius);
	double index_i_temp = 0.0;
	PolarCoordinate polCoord = Cartesian2Polar(carCoord);
	if(gridRatio == 1)
	{
		index_i_temp = (polCoord.r - dataRange_radius.min) / basicRadius;
	}
	else
	{
		double temp = 1 - (1 - gridRatio) * (polCoord.r - dataRange_radius.min) / basicRadius;
		index_i_temp = log(temp) / log(gridRatio);
	}
	Index index;
	index.i = ceil(index_i_temp);
	DataRange dataRange_angle = GetDataRange(fieldAngle);
	double index_j_temp = 0.0;
	index_j_temp = (polCoord.theta - dataRange_angle.min) / dataRange_angle.range * angleNum;
	index.j = ceil(index_j_temp);
	return index;
}

struct ScalarField
{
	double x;
	double y;
	double z;
	double v;
};

//-------------description of input parameters--------------//
//--argv[1]: file path of dsplot
//--argv[2]: param.ist
//--argv[3]: path of output file floder
//--argv[4]: numbers of angle
//--argv[5]: numbers of radius
//--argv[6]: ratio of grid
//----------------------------------------------------------//

int main(int argc,char** argv)
{
	//======================D3plotReader======================
	string d3plot_file = argv[1];
	string::size_type pos = d3plot_file.find('/');
	while(pos != string::npos)
	{
		d3plot_file.replace(pos, 1, "\\");
		pos = d3plot_file.find('/');
	}
	D3plotReader dr(d3plot_file.c_str());
	D3P_Parameter param;
	cout << "=============== D3plotReader ===============" << endl;

	char title[80];
	dr.GetData(D3P_TITLE, (char*)title);
	cout << "title: " << title << endl;

	int num_states = 0;
	dr.GetData(D3P_NUM_STATES, (char*)&num_states);
	cout << "num states: " << num_states << endl;

	param.ist = atoi(argv[2]);
	cout << "current state: " << param.ist << endl;
	
	int num_nodes = 0;
	dr.GetData(D3P_NUM_NODES, (char*)&num_nodes, param);
	cout << "num nodes: " << num_nodes << endl;

	D3P_VectorDouble* dcoords = new D3P_VectorDouble[num_nodes];
	dr.GetData(D3P_NODE_COORDINATES_DOUBLE, (char*)dcoords, param);

	int num_shell_elements = 0;
	dr.GetData(D3P_NUM_SHELL, (char*)&num_shell_elements, param);
	cout << "num shells: " << num_shell_elements << endl;

	D3P_Shell* shells = new D3P_Shell[num_shell_elements];
	dr.GetData(D3P_SHELL_CONNECTIVITY_MAT, (char*)shells, param);
	
	param.ipt = 0;
	D3P_Tensor* shell_stress = new D3P_Tensor[num_shell_elements];
	dr.GetData(D3P_SHELL_STRESS, (char*)shell_stress, param);
	//======================Arrange Raw Data======================
	vector<ScalarField> data(num_shell_elements);
	int len_tensor = 3;
	double Xmin = 0;
	double Xmax = 0;
	for(int i = 0; i != num_shell_elements; ++i)
	{
		double coord_x_temp = 0;
		double coord_y_temp = 0;
		double coord_z_temp = 0;
		int len_conn_all = sizeof(shells[0].conn) / sizeof(shells[0].conn[0]);
		int len_conn_used = 0;
		double value_temp = 0;
		for(int j = 0;j != len_conn_all; ++j)
		{
			if(shells[i].conn[j] > 0)
			{
				++len_conn_used;
				coord_x_temp = coord_x_temp + dcoords[shells[i].conn[j] - 1].v[0];
				coord_y_temp = coord_y_temp + dcoords[shells[i].conn[j] - 1].v[1];
				coord_z_temp = coord_z_temp + dcoords[shells[i].conn[j] - 1].v[2];
			}
			else
			{
				break;
			}
		}
		coord_x_temp = coord_x_temp / len_conn_used;
		if(coord_x_temp < Xmin)
		{
			Xmin = coord_x_temp;
		}
		else if(coord_x_temp > Xmax)
		{
			Xmax = coord_x_temp;
		}
		coord_y_temp = coord_y_temp / len_conn_used;
		coord_z_temp = coord_z_temp / len_conn_used;
		for(int j = 0; j != len_tensor; ++j)
		{
			value_temp = value_temp + shell_stress[i].t[j];
		}
		value_temp = value_temp / len_tensor;
		value_temp = -value_temp;
		data.at(i).x = coord_x_temp;
		data.at(i).y = coord_y_temp;
		data.at(i).z = coord_z_temp;
		data.at(i).v = value_temp;
	}
	
	//======================Original Data File======================
	string output_folder = argv[3];
	string output_file;
	ofstream fs_output;

	if(param.ist == 0)
	{
		//Output the data - original Coord
		output_file = output_folder + "original_Coord";
		fs_output.open(output_file, ios::out);
		fs_output.precision(8);
		for(int i = 0; i != data.size(); ++i)
		{
			fs_output << data.at(i).x << '\t' << data.at(i).y << '\t' 
			<< data.at(i).z << endl;
		}
		fs_output.close();
	}

	output_file = output_folder + "PRESSURE/original_Var_" + to_string(param.ist);
	fs_output.open(output_file, ios::out);
	fs_output.precision(8);
	for(int i = 0; i != data.size(); ++i)
	{
		fs_output << data.at(i).v << endl;
	}
	fs_output.close();

	//======================Arrange Result Data and Output======================
	angleNum = atof(argv[4]);
	radiusNum = atof(argv[5]);
	gridRatio = atof(argv[6]);

	vector<double> fieldRadius;
	fieldRadius.push_back(Xmin);
	fieldRadius.push_back(Xmax);

	vector<double> fieldAngle;
	fieldAngle.push_back(-PI/2);
	fieldAngle.push_back(PI/2);

	vector<vector<double>> result_X(radiusNum + 2, vector<double>(angleNum + 2, -10000));
	vector<vector<double>> result_Y(radiusNum + 2, vector<double>(angleNum + 2, -10000));
	vector<vector<double>> result_V(radiusNum + 2, vector<double>(angleNum + 2, -10000));

	for(int i = 0; i != data.size(); ++i)
	{
		CartesianCoordinate carCoord;
		carCoord.x = data.at(i).x;
		carCoord.y = data.at(i).y;
		Index index_temp = GetIndex_CircleField(carCoord, fieldRadius, fieldAngle);
		result_X.at(index_temp.i).at(index_temp.j) = data.at(i).x;
		result_Y.at(index_temp.i).at(index_temp.j) = data.at(i).y;
		result_V.at(index_temp.i).at(index_temp.j) = data.at(i).v;
	}

	//Output data: reform Coord
	if(param.ist == 0)
	{
		string output_X = output_folder + "reform_CoordX";
		fs_output.open(output_X, ios::out);
		for(int i = 0; i != result_X.size(); i++)
		{
			for(int j = 0; j != result_X.at(0).size(); j++)
			{
				fs_output << result_X.at(i).at(j) << '\t';
			}
			fs_output << endl;
		}
		fs_output.close();

		string output_Y = output_folder + "reform_CoordY";
		fs_output.open(output_Y, ios::out);
		for(int i = 0; i != result_Y.size(); i++)
		{
			for(int j = 0; j != result_Y.at(0).size(); j++)
			{
				fs_output << result_Y.at(i).at(j) << '\t';
			}
			fs_output << endl;
		}
		fs_output.close();
	}

	string output_V = output_folder + "PRESSURE/reform_Var_" + to_string(param.ist);
	fs_output.open(output_V, ios::out);
	for(int i = 0; i != result_V.size(); i++)
	{
		for(int j = 0; j != result_V.at(0).size(); j++)
		{
			fs_output << result_V.at(i).at(j) << '\t';
		}
		fs_output << endl;
	}
	fs_output.close();
}
