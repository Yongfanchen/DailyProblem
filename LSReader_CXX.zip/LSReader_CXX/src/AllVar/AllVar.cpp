#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include <math.h>
#include <algorithm>

#include "d3plotreader.h"
#include "binoutreader.h"

#define PI 3.141592653589793

using namespace std;

double angleNum = 0;
double radiusNum = 0;
double gridRatio = 0;

struct DataRange
{
	double range;
	double min;
	double max;
};

DataRange GetDataRange(vector<double> data)
{
	DataRange dataRange;
	auto maxPos = max_element(data.begin(), data.end());
	auto minPos = min_element(data.begin(), data.end());
	dataRange.range = abs(*maxPos - *minPos);
	dataRange.min = *minPos;
	dataRange.max = *maxPos;
	return dataRange;
}

struct PolarCoordinate
{
	double r;
	double theta;
};

struct CartesianCoordinate
{
	double x;
	double y;
};

PolarCoordinate Cartesian2Polar(CartesianCoordinate carCoord)
{
	PolarCoordinate polCoord;
	polCoord.r = sqrt(pow(carCoord.x,2) + pow(carCoord.y,2));
	if(polCoord.r == 0)
	{
		polCoord.theta = 0;
	}
	else
	{
		polCoord.theta = atan2(carCoord.y,carCoord.x);
	}
	return polCoord;
}

struct Polygon
{
	struct Vertex
	{
		CartesianCoordinate coord;
		double angle;
		bool operator < (const Vertex &ver) const
		{
			return angle < ver.angle;
		}
	};

	vector<CartesianCoordinate> polygonCoord;
	vector<Vertex> vertexs;
	CartesianCoordinate centroid;
	double area;

	Polygon(vector<CartesianCoordinate> coords)
	{
		polygonCoord = coords;
		GetCentroid();
		Vertex vertex_temp;
		PolarCoordinate polar_temp;
		for(int i = 0; i < polygonCoord.size(); i++)
		{
			vertex_temp.coord.x = polygonCoord.at(i).x - centroid.x;
			vertex_temp.coord.y = polygonCoord.at(i).y - centroid.y;
			polar_temp = Cartesian2Polar(vertex_temp.coord);
			vertex_temp.angle = polar_temp.theta;
			vertexs.push_back(vertex_temp);
		}
		sort(vertexs.begin(), vertexs.end());
		ComputePolygonArea();
	}
	
	void GetCentroid()
	{
		centroid.x = 0;
		centroid.y = 0;
		for(int i = 0; i < polygonCoord.size(); i++)
		{
			centroid.x += polygonCoord.at(i).x;
			centroid.y += polygonCoord.at(i).y;
		}
		centroid.x = centroid.x / polygonCoord.size();
		centroid.y = centroid.y / polygonCoord.size();
	}

	void ComputePolygonArea()
	{
		int point_num = vertexs.size();
		area = 0;
		if(point_num < 3)
		{
			return;
		}
		for(int i = 0; i < point_num; ++i)
		{
			area += vertexs.at(i).coord.x * vertexs.at((i+1) % point_num).coord.y 
				  - vertexs.at(i).coord.y * vertexs.at((i+1) % point_num).coord.x;
		}
		area = abs(area / 2);
	}
};

struct Index
{
	int i;
	int j;
};

double GetCoreRadius(vector<double> filedRadius)
{
	DataRange dataRange_radius = GetDataRange(filedRadius);
	double basicRadius = 0.0;
	if(gridRatio == 1)
	{
		basicRadius = dataRange_radius.range / radiusNum;
	}
	else
	{
		basicRadius = dataRange_radius.range * (1 - gridRatio) / (1 - pow(gridRatio, radiusNum));
	}
	return basicRadius;
}

Index GetIndex_CircleField(CartesianCoordinate carCoord, vector<double> fieldRadius, vector<double> fieldAngle)
{
	DataRange dataRange_radius = GetDataRange(fieldRadius);
	double basicRadius = GetCoreRadius(fieldRadius);
	double index_i_temp = 0.0;
	PolarCoordinate polCoord = Cartesian2Polar(carCoord);
	if(gridRatio == 1)
	{
		index_i_temp = (polCoord.r - dataRange_radius.min) / basicRadius;
	}
	else
	{
		double temp = 1 - (1 - gridRatio) * (polCoord.r - dataRange_radius.min) / basicRadius;
		index_i_temp = log(temp) / log(gridRatio);
	}
	Index index;
	index.i = ceil(index_i_temp);
	DataRange dataRange_angle = GetDataRange(fieldAngle);
	double index_j_temp = 0.0;
	index_j_temp = (polCoord.theta - dataRange_angle.min) / dataRange_angle.range * angleNum;
	index.j = ceil(index_j_temp);
	return index;
}

struct ScalarField
{
	double x;
	double y;
	double z;
	double v;
};

struct VectorField
{
	double x;
	double y;
	double z;
	vector<double> v;
};

//-------------description of input parameters--------------//
//--argv[1]: file path of dsplot
//--argv[2]: param.ist
//--argv[3]: param.id_fluid_group
//--argv[4]: path of output file floder
//--argv[5]: numbers of angle
//--argv[6]: numbers of radius
//--argv[7]: ratio of grid
//----------------------------------------------------------//

int main(int argc,char** argv)
{
	//======================D3plotReader======================
	string d3plot_file = argv[1];
	string::size_type pos = d3plot_file.find('/');
	while(pos != string::npos)
	{
		d3plot_file.replace(pos, 1, "\\");
		pos = d3plot_file.find('/');
	}
	D3plotReader dr(d3plot_file.c_str());
	D3P_Parameter param;
	cout << "=============== D3plotReader ===============" << endl;

	char title[80];
	dr.GetData(D3P_TITLE, (char*)title);
	cout << "title: " << title << endl;

	int num_states = 0;
	dr.GetData(D3P_NUM_STATES, (char*)&num_states);
	cout << "num states: " << num_states << endl;

	param.ist = atoi(argv[2]);
	cout << "current state: " << param.ist << endl;
	
	int num_nodes = 0;
	dr.GetData(D3P_NUM_NODES, (char*)&num_nodes, param);
	cout << "num nodes: " << num_nodes << endl;

	//COORDINATE
	D3P_VectorDouble* dcoords = new D3P_VectorDouble[num_nodes];
	dr.GetData(D3P_NODE_COORDINATES_DOUBLE, (char*)dcoords, param);

	//VELOCITY
	D3P_VectorDouble* dvelocity = new D3P_VectorDouble[num_nodes];
	dr.GetData(D3P_NODE_VELOCITIES_DOUBLE, (char*)dvelocity, param);

	int num_shell_elements = 0;
	dr.GetData(D3P_NUM_SHELL, (char*)&num_shell_elements, param);
	cout << "num shells: " << num_shell_elements << endl;

	D3P_Shell* shells = new D3P_Shell[num_shell_elements];
	dr.GetData(D3P_SHELL_CONNECTIVITY_MAT, (char*)shells, param);

	int num_ale_group = 0;
	dr.GetData(D3P_ALE_NUM_FLUID_GROUP, (char*)&num_ale_group, param);
	cout << "num ale fluid group: " << num_ale_group << endl;

	//VOLUME_FRACTION
	param.id_fluid_group = atoi(argv[3]);
	float* shell_volume_fraction =  new float[num_shell_elements];
	dr.GetData(D3P_2D_ALE_VOLUME_FRACTION, (char*)shell_volume_fraction, param);

	//Ei density
	float* shell_internal_energy_density =  new float[num_shell_elements];
	dr.GetData(D3P_SHELL_INTERNAL_ENERGY_DENSITY, (char*)shell_internal_energy_density, param);

	//Density
	float* shell_density =  new float[num_shell_elements];
	dr.GetData(D3P_2D_ALE_DENSITY, (char*)shell_density, param);
	//======================Arrange Raw Data======================
	vector<ScalarField> data_VF(num_shell_elements);
	vector<VectorField> data_Vel(num_shell_elements);
	double Xmin = 0;
	double Xmax = 0;
	double volume = 0;
	double Ei = 0;
	double Ek = 0;
	for(int i = 0; i != num_shell_elements; ++i)
	{
		double coord_x_temp = 0;
		double coord_y_temp = 0;
		double coord_z_temp = 0;
		double velocity_x_temp = 0;
		double velocity_y_temp = 0;
		double velocity_z_temp = 0;
		vector<CartesianCoordinate> coords;
		CartesianCoordinate carte_temp;
		int len_conn_all = sizeof(shells[0].conn) / sizeof(shells[0].conn[0]);
		int len_conn_used = 0;
		for(int j = 0;j != len_conn_all; ++j)
		{
			if(shells[i].conn[j] > 0)
			{
				++len_conn_used;
				coord_x_temp = coord_x_temp + dcoords[shells[i].conn[j] - 1].v[0];
				coord_y_temp = coord_y_temp + dcoords[shells[i].conn[j] - 1].v[1];
				coord_z_temp = coord_z_temp + dcoords[shells[i].conn[j] - 1].v[2];
				velocity_x_temp = velocity_x_temp + dvelocity[shells[i].conn[j] - 1].v[0];
				velocity_y_temp = velocity_y_temp + dvelocity[shells[i].conn[j] - 1].v[1];
				velocity_z_temp = velocity_z_temp + dvelocity[shells[i].conn[j] - 1].v[2];
				carte_temp.x = dcoords[shells[i].conn[j] - 1].v[0];
				carte_temp.y = dcoords[shells[i].conn[j] - 1].v[1];
				coords.push_back(carte_temp);
			}
			else
			{
				break;
			}
		}
		coord_x_temp = coord_x_temp / len_conn_used;
		if(coord_x_temp < Xmin)
		{
			Xmin = coord_x_temp;
		}
		else if(coord_x_temp > Xmax)
		{
			Xmax = coord_x_temp;
		}
		coord_y_temp = coord_y_temp / len_conn_used;
		coord_z_temp = coord_z_temp / len_conn_used;
		//VF
		data_VF.at(i).x = coord_x_temp;
		data_VF.at(i).y = coord_y_temp;
		data_VF.at(i).z = coord_z_temp;
		data_VF.at(i).v = (double)shell_volume_fraction[i];
		//Vel
		data_Vel.at(i).x = coord_x_temp;
		data_Vel.at(i).y = coord_y_temp;
		data_Vel.at(i).z = coord_z_temp;
		velocity_x_temp = velocity_x_temp / len_conn_used;
		velocity_y_temp = velocity_y_temp / len_conn_used;
		velocity_z_temp = velocity_z_temp / len_conn_used;
		data_Vel.at(i).v.push_back(velocity_x_temp);
		data_Vel.at(i).v.push_back(velocity_y_temp);
		data_Vel.at(i).v.push_back(velocity_z_temp);
		//Volume
		Polygon polygon(coords);
		volume += polygon.area * 2 * PI * polygon.centroid.x * data_VF.at(i).v;
		//Ei
		double volume_temp = polygon.area * 2 * PI * polygon.centroid.x;
		double Ei_density = shell_internal_energy_density[i] / polygon.centroid.x;
		Ei += Ei_density * shell_volume_fraction[i] * volume_temp;
		//Ek
		double velocity_temp = sqrt(pow(velocity_x_temp,2) + pow(velocity_y_temp,2) + pow(velocity_z_temp,2));
		double Ek_density = 1.0 / 2.0  * shell_density[i] * pow(velocity_temp, 2);
		Ek += Ek_density * shell_volume_fraction[i] *  volume_temp;
	}
	
	//======================Original Data File======================
	string output_folder = argv[4];

	string output_file;
	ofstream fs_output;
	if(param.ist == 0)
	{
		//Output the data - original Coord
		output_file = output_folder + "original_Coord";
		fs_output.open(output_file, ios::out);
		fs_output.precision(8);
		for(int i = 0; i != data_VF.size(); ++i)
		{
			fs_output << data_VF.at(i).x << '\t' << data_VF.at(i).y << '\t' 
			<< data_VF.at(i).z << endl;
		}
		fs_output.close();
	}

	//Output the data - original Volume Fraction
	output_file = output_folder + "VOLUME_FRACTION/original_Var_" + to_string(param.ist);
	fs_output.open(output_file, ios::out);
	fs_output.precision(8);
	for(int i = 0; i != data_VF.size(); ++i)
	{
		fs_output << data_VF.at(i).v << endl;
	}
	fs_output.close();

	//Output the data - original Velocity
	output_file = output_folder + "VELOCITY/original_Var_" + to_string(param.ist);
	fs_output.open(output_file, ios::out);
	fs_output.precision(8);
	for(int i = 0; i != data_Vel.size(); ++i)
	{
		for (int j = 0; j < data_Vel.at(i).v.size(); j++)
		{
			fs_output << data_Vel.at(i).v.at(j) << '\t';
		}
		fs_output << endl;
	}
	fs_output.close();

	//Output the data - volume
	output_file = output_folder + "VOLUME/value_" + to_string(param.ist);
	fs_output.open(output_file, ios::out);
	fs_output.precision(8);
	fs_output << volume << endl;
	fs_output.close();

	//Output the data - Ei
	output_file = output_folder + "INTERNAL_ENERGY/value_" + to_string(param.ist);
	fs_output.open(output_file, ios::out);
	fs_output.precision(8);
	fs_output << Ei << endl;
	fs_output.close();

	//Output the data - Ek
	output_file = output_folder + "KINETIC_ENERGY/value_" + to_string(param.ist);
	fs_output.open(output_file, ios::out);
	fs_output.precision(8);
	fs_output << Ek << endl;
	fs_output.close();

	//======================Arrange Result Data and Output======================
	angleNum = atof(argv[5]);
	radiusNum = atof(argv[6]);
	gridRatio = atof(argv[7]);

	vector<double> fieldRadius;
	fieldRadius.push_back(Xmin);
	fieldRadius.push_back(Xmax);

	vector<double> fieldAngle;
	fieldAngle.push_back(-PI/2);
	fieldAngle.push_back(PI/2);

	vector<vector<double>> result_X(radiusNum + 2, vector<double>(angleNum + 2, -10000));
	vector<vector<double>> result_Y(radiusNum + 2, vector<double>(angleNum + 2, -10000));
	vector<vector<double>> result_VF(radiusNum + 2, vector<double>(angleNum + 2, -10000));
	vector<vector<double>> result_Vx(radiusNum + 2, vector<double>(angleNum + 2, -10000));
	vector<vector<double>> result_Vy(radiusNum + 2, vector<double>(angleNum + 2, -10000));
	vector<vector<double>> result_Vz(radiusNum + 2, vector<double>(angleNum + 2, -10000));

	for(int i = 0; i != data_VF.size(); ++i)
	{
		CartesianCoordinate carCoord;
		carCoord.x = data_VF.at(i).x;
		carCoord.y = data_VF.at(i).y;
		Index index_temp = GetIndex_CircleField(carCoord, fieldRadius, fieldAngle);
		result_X.at(index_temp.i).at(index_temp.j) = data_VF.at(i).x;
		result_Y.at(index_temp.i).at(index_temp.j) = data_VF.at(i).y;
		result_VF.at(index_temp.i).at(index_temp.j) = data_VF.at(i).v;
		result_Vx.at(index_temp.i).at(index_temp.j) = data_Vel.at(i).v.at(0);
		result_Vy.at(index_temp.i).at(index_temp.j) = data_Vel.at(i).v.at(1);
		result_Vz.at(index_temp.i).at(index_temp.j) = data_Vel.at(i).v.at(2);
	}

	//Output data: reform Coord
	if(param.ist == 0)
	{
		string output_X = output_folder + "reform_CoordX";
		fs_output.open(output_X, ios::out);
		for(int i = 0; i != result_X.size(); i++)
		{
			for(int j = 0; j != result_X.at(0).size(); j++)
			{
				fs_output << result_X.at(i).at(j) << '\t';
			}
			fs_output << endl;
		}
		fs_output.close();

		string output_Y = output_folder + "reform_CoordY";
		fs_output.open(output_Y, ios::out);
		for(int i = 0; i != result_Y.size(); i++)
		{
			for(int j = 0; j != result_Y.at(0).size(); j++)
			{
				fs_output << result_Y.at(i).at(j) << '\t';
			}
			fs_output << endl;
		}
		fs_output.close();
	}
	
	
	string output_VF = output_folder + "VOLUME_FRACTION/reform_VarX_" + to_string(param.ist);
	string output_Vx = output_folder + "VELOCITY/reform_VarX_" + to_string(param.ist);
	string output_Vy = output_folder + "VELOCITY/reform_VarY_" + to_string(param.ist);
	string output_Vz = output_folder + "VELOCITY/reform_VarZ_" + to_string(param.ist);

	fs_output.open(output_VF, ios::out);
	for(int i = 0; i != result_VF.size(); i++)
	{
		for(int j = 0; j != result_VF.at(0).size(); j++)
		{
			fs_output << result_VF.at(i).at(j) << '\t';
		}
		fs_output << endl;
	}
	fs_output.close();


	fs_output.open(output_Vx, ios::out);
	for(int i = 0; i != result_Vx.size(); i++)
	{
		for(int j = 0; j != result_Vx.at(0).size(); j++)
		{
			fs_output << result_Vx.at(i).at(j) << '\t';
		}
		fs_output << endl;
	}
	fs_output.close();

	fs_output.open(output_Vy, ios::out);
	for(int i = 0; i != result_Vy.size(); i++)
	{
		for(int j = 0; j != result_Vy.at(0).size(); j++)
		{
			fs_output << result_Vy.at(i).at(j) << '\t';
		}
		fs_output << endl;
	}
	fs_output.close();

	fs_output.open(output_Vz, ios::out);
	for(int i = 0; i != result_Vz.size(); i++)
	{
		for(int j = 0; j != result_Vz.at(0).size(); j++)
		{
			fs_output << result_Vz.at(i).at(j) << '\t';
		}
		fs_output << endl;
	}
	fs_output.close();
}
